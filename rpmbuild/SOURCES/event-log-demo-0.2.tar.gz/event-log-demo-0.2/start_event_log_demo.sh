#!/bin/sh

start_flume.sh
start_kibana.sh
