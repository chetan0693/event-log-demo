#!/bin/sh 


cd /usr/local/kibana-0.3.0/
nohup scripts/server.js &
